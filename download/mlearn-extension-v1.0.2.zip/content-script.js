"use strict";
(() => {
  // extension/src/headless/subtitleParser.ts
  function parseSRT(content) {
    const subtitles = [];
    const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const blocks = normalized.trim().split(/\n\n+/);
    for (const block of blocks) {
      const lines = block.split("\n");
      if (lines.length < 3) continue;
      const timeLine = lines[1];
      const timeMatch = timeLine.match(
        /(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})/
      );
      if (!timeMatch) continue;
      const start = parseInt(timeMatch[1]) * 3600 + parseInt(timeMatch[2]) * 60 + parseInt(timeMatch[3]) + parseInt(timeMatch[4]) / 1e3;
      const end = parseInt(timeMatch[5]) * 3600 + parseInt(timeMatch[6]) * 60 + parseInt(timeMatch[7]) + parseInt(timeMatch[8]) / 1e3;
      const text = lines.slice(2).join("\n").replace(/<[^>]*>/g, "");
      subtitles.push({ start, end, text });
    }
    return subtitles;
  }
  function parseVTT(content) {
    const subtitles = [];
    const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = normalized.split("\n");
    let i = 0;
    while (i < lines.length && !lines[i].includes("-->")) {
      i++;
    }
    while (i < lines.length) {
      const line = lines[i].trim();
      if (!line || !line.includes("-->")) {
        if (line && !line.match(/^\d{2}:/)) {
          i++;
          continue;
        }
        if (!line) {
          i++;
          continue;
        }
      }
      const timeLine = lines[i];
      const timeMatch = timeLine.match(
        /(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})/
      );
      let start = 0;
      let end = 0;
      let parsed = false;
      if (timeMatch) {
        start = parseInt(timeMatch[1]) * 3600 + parseInt(timeMatch[2]) * 60 + parseInt(timeMatch[3]) + parseInt(timeMatch[4]) / 1e3;
        end = parseInt(timeMatch[5]) * 3600 + parseInt(timeMatch[6]) * 60 + parseInt(timeMatch[7]) + parseInt(timeMatch[8]) / 1e3;
        parsed = true;
      } else {
        const shortMatch = timeLine.match(
          /(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2})[.,](\d{3})/
        );
        if (shortMatch) {
          start = parseInt(shortMatch[1]) * 60 + parseInt(shortMatch[2]) + parseInt(shortMatch[3]) / 1e3;
          end = parseInt(shortMatch[4]) * 60 + parseInt(shortMatch[5]) + parseInt(shortMatch[6]) / 1e3;
          parsed = true;
        }
      }
      if (!parsed) {
        i++;
        continue;
      }
      i++;
      const textLines = [];
      while (i < lines.length && lines[i].trim() && !lines[i].includes("-->")) {
        textLines.push(lines[i].replace(/<[^>]*>/g, ""));
        i++;
      }
      if (textLines.length > 0) {
        subtitles.push({ start, end, text: textLines.join("\n") });
      }
    }
    return subtitles;
  }
  function parseASS(content) {
    const subtitles = [];
    const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = normalized.split("\n");
    let inEvents = false;
    let formatFields = [];
    for (const line of lines) {
      if (line.startsWith("[Events]")) {
        inEvents = true;
        continue;
      }
      if (line.startsWith("[") && inEvents) {
        break;
      }
      if (inEvents) {
        if (line.startsWith("Format:")) {
          formatFields = line.substring(7).split(",").map((f) => f.trim().toLowerCase());
          continue;
        }
        if (line.startsWith("Dialogue:")) {
          let dialogueLine = line;
          if (dialogueLine.includes("Marked=")) {
            dialogueLine = dialogueLine.replace(/Marked=\d+/, "");
          }
          const parts = dialogueLine.substring(9).split(",");
          const startIdx = formatFields.indexOf("start");
          const endIdx = formatFields.indexOf("end");
          const textIdx = formatFields.indexOf("text");
          if (startIdx === -1 || endIdx === -1 || textIdx === -1) continue;
          const parseTime = (timeStr) => {
            const match = timeStr.trim().match(/(\d+):(\d{2}):(\d{2})\.(\d{2})/);
            if (!match) return 0;
            return parseInt(match[1]) * 3600 + parseInt(match[2]) * 60 + parseInt(match[3]) + parseInt(match[4]) / 100;
          };
          const start = parseTime(parts[startIdx]);
          const end = parseTime(parts[endIdx]);
          let text = parts.slice(textIdx).join(",");
          text = text.replace(/\{[^}]*\}/g, "").replace(/\\N/g, "\n").replace(/\\n/g, "\n");
          subtitles.push({ start, end, text: text.trim() });
        }
      }
    }
    return subtitles;
  }
  function detectSubtitleFormat(content) {
    if (content.includes("WEBVTT")) {
      return "vtt";
    }
    if (content.includes("[Script Info]") || content.includes("[V4+ Styles]")) {
      return "ass";
    }
    return "srt";
  }
  function parseSubtitles(content, format) {
    const detectedFormat = format || detectSubtitleFormat(content);
    switch (detectedFormat) {
      case "vtt":
        return parseVTT(content);
      case "ass":
        return parseASS(content);
      default:
        return parseSRT(content);
    }
  }
  function findCurrentSubtitle(subtitles, time, offset) {
    const adjustedTime = time + offset;
    let lo = 0;
    let hi = subtitles.length - 1;
    let found = -1;
    while (lo <= hi) {
      const mid = lo + hi >>> 1;
      if (subtitles[mid].start <= adjustedTime) {
        found = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    if (found === -1) return null;
    if (adjustedTime > subtitles[found].end) return null;
    return subtitles[found];
  }

  // extension/src/headless/subtitleInjector.ts
  var SUBTITLE_CONTAINER_ID = "mlearn-headless-subtitles";
  var SUBTITLE_STYLE_ID = "mlearn-headless-subtitle-styles";
  var subtitleContainer = null;
  var currentSubtitles = [];
  var currentOffset = 0;
  var lastText = null;
  var isEnabled = false;
  var currentFontSize = 22;
  function buildStyles(fontSize) {
    return `
  #${SUBTITLE_CONTAINER_ID} {
    position: fixed;
    bottom: 56px;
    left: 0;
    right: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    pointer-events: none;
    z-index: 999999;
    font-family: 'Helvetica Neue', -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
    font-size: ${fontSize}px;
    font-weight: 600;
    line-height: 1.5;
    color: #ffffff;
    text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;
    text-align: center;
    padding: 0 24px;
    box-sizing: border-box;
    transition: opacity 0.25s cubic-bezier(0.4, 0, 0.2, 1), transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  }
  #${SUBTITLE_CONTAINER_ID}.hidden {
    opacity: 0;
    transform: translateY(6px);
  }
  #${SUBTITLE_CONTAINER_ID} .subtitle-line {
    display: inline-block;
    padding: 6px 16px;
    max-width: 90%;
    word-wrap: break-word;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`;
  }
  function injectStyles() {
    const existing = document.getElementById(SUBTITLE_STYLE_ID);
    if (existing) {
      existing.textContent = buildStyles(currentFontSize);
      return;
    }
    const style = document.createElement("style");
    style.id = SUBTITLE_STYLE_ID;
    style.textContent = buildStyles(currentFontSize);
    document.head.appendChild(style);
  }
  function removeStyles() {
    const style = document.getElementById(SUBTITLE_STYLE_ID);
    if (style) {
      style.remove();
    }
  }
  function getAllVideos(root = document) {
    const found = [];
    try {
      const videos = root.querySelectorAll("video");
      for (const video of Array.from(videos)) {
        found.push(video);
      }
    } catch {
    }
    const allElements = root.querySelectorAll("*");
    for (const el of Array.from(allElements)) {
      if (el.shadowRoot) {
        found.push(...getAllVideos(el.shadowRoot));
      }
    }
    return found;
  }
  function getBestVideo() {
    const videos = getAllVideos(document);
    let best = null;
    let bestArea = 0;
    for (const video of videos) {
      const rect = video.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area > bestArea && rect.width > 0 && rect.height > 0) {
        bestArea = area;
        best = video;
      }
    }
    return best;
  }
  function createSubtitleContainer() {
    removeContainer();
    injectStyles();
    const container = document.createElement("div");
    container.id = SUBTITLE_CONTAINER_ID;
    container.classList.add("hidden");
    const line = document.createElement("span");
    line.className = "subtitle-line";
    container.appendChild(line);
    document.body.appendChild(container);
    return container;
  }
  function handleResize() {
    if (!isEnabled) return;
    const video = getBestVideo();
    if (video && subtitleContainer) {
      positionSubtitleOverVideo(video);
    }
  }
  function handleScroll() {
    if (!isEnabled) return;
    const video = getBestVideo();
    if (video && subtitleContainer) {
      positionSubtitleOverVideo(video);
    }
  }
  function positionSubtitleOverVideo(video) {
    if (!subtitleContainer) return;
    const rect = video.getBoundingClientRect();
    subtitleContainer.style.top = `${rect.top + rect.height - 96}px`;
    subtitleContainer.style.left = `${rect.left}px`;
    subtitleContainer.style.width = `${rect.width}px`;
    subtitleContainer.style.height = "auto";
    subtitleContainer.style.right = "auto";
    subtitleContainer.style.bottom = "auto";
  }
  function updateSubtitleText(text) {
    if (!subtitleContainer) return;
    const line = subtitleContainer.querySelector(".subtitle-line");
    if (!line) return;
    if (text) {
      line.textContent = text;
      subtitleContainer.classList.remove("hidden");
    } else {
      subtitleContainer.classList.add("hidden");
    }
  }
  function enableSubtitleInjection() {
    if (isEnabled) return;
    isEnabled = true;
    if (!subtitleContainer) {
      subtitleContainer = createSubtitleContainer();
    }
    const video = getBestVideo();
    if (video) {
      positionSubtitleOverVideo(video);
    }
    window.addEventListener("resize", handleResize);
    window.addEventListener("scroll", handleScroll, true);
  }
  function disableSubtitleInjection() {
    if (!isEnabled) return;
    isEnabled = false;
    removeContainer();
    removeStyles();
    window.removeEventListener("resize", handleResize);
    window.removeEventListener("scroll", handleScroll, true);
  }
  function removeContainer() {
    const existing = document.getElementById(SUBTITLE_CONTAINER_ID);
    if (existing) {
      existing.remove();
    }
    subtitleContainer = null;
  }
  function loadSubtitles(subtitles) {
    currentSubtitles = subtitles;
  }
  function setSubtitleOffset(offset) {
    currentOffset = offset;
  }
  function updateSubtitleForTime(currentTime) {
    if (!isEnabled || currentSubtitles.length === 0) return;
    const subtitle = findCurrentSubtitle(currentSubtitles, currentTime, currentOffset);
    const text = subtitle?.text || null;
    if (text === lastText) return;
    lastText = text;
    updateSubtitleText(text);
    const video = getBestVideo();
    if (video && subtitleContainer) {
      positionSubtitleOverVideo(video);
    }
  }
  function adjustFontSize(delta) {
    currentFontSize = Math.max(10, Math.min(60, currentFontSize + delta));
    injectStyles();
    return currentFontSize;
  }

  // extension/src/platforms/generic.ts
  function toSRTTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    const ms = Math.floor(seconds % 1 * 1e3);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")},${String(ms).padStart(3, "0")}`;
  }
  var genericPlatform = {
    name: "generic",
    matchesUrl() {
      return true;
    },
    startMonitoring(video, onSubtitlesChanged) {
      const result = this.extractOnce?.(video);
      if (result) {
        onSubtitlesChanged(result);
      }
      return () => {
      };
    },
    extractOnce(video) {
      const tracks = [];
      const textTracks = [];
      for (const track of Array.from(video.querySelectorAll("track"))) {
        tracks.push({
          kind: track.kind,
          src: track.src,
          srclang: track.srclang,
          label: track.label
        });
      }
      if (video.textTracks) {
        for (let i = 0; i < video.textTracks.length; i++) {
          const tt = video.textTracks[i];
          if (tt.mode === "showing" || tt.mode === "hidden") {
            const cueList = tt.cues;
            if (cueList && cueList.length > 0) {
              const srtCues = [];
              for (let j = 0; j < cueList.length; j++) {
                const cue = cueList[j];
                if (cue.text) {
                  srtCues.push(
                    `${j + 1}
${toSRTTime(cue.startTime)} --> ${toSRTTime(cue.endTime)}
${cue.text}`
                  );
                }
              }
              if (srtCues.length > 0) {
                textTracks.push({
                  language: tt.language || tt.label || "unknown",
                  text: srtCues.join("\n\n")
                });
              }
            }
          }
        }
      }
      if (tracks.length === 0 && textTracks.length === 0) {
        return null;
      }
      return { tracks, textTracks };
    }
  };

  // extension/src/platforms/youtube.ts
  var CAPTION_CONTAINER_SELECTOR = ".ytp-caption-window-container";
  var NATIVE_CAPTIONS_STYLE_ID = "mlearn-hide-youtube-captions";
  var ACTIVE_CAPTION_END_TIME = 359999;
  var MAX_FINALIZED_ENTRIES = 50;
  var EMIT_THROTTLE_MS = 500;
  function toSRTTime2(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    const ms = Math.floor(seconds % 1 * 1e3);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")},${String(ms).padStart(3, "0")}`;
  }
  function generateSRT(entries) {
    return entries.map((entry, index) => {
      return `${index + 1}
${toSRTTime2(entry.start)} --> ${toSRTTime2(entry.end)}
${entry.text}`;
    }).join("\n\n");
  }
  function isUiOnlyText(text) {
    return text.includes("Click for settings") || /\(auto-generated\)/.test(text);
  }
  function showNativeCaptions() {
    const existing = document.getElementById(NATIVE_CAPTIONS_STYLE_ID);
    if (existing) existing.remove();
  }
  function hideNativeCaptions() {
    if (document.getElementById(NATIVE_CAPTIONS_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = NATIVE_CAPTIONS_STYLE_ID;
    style.textContent = ".ytp-caption-window-container { opacity: 0 !important; }";
    document.head.appendChild(style);
  }
  function extractCaptionText(container) {
    const windows = container.querySelectorAll(".caption-window, .ytp-caption-window");
    if (windows.length === 0) return null;
    const targetWindow = windows[windows.length - 1];
    const lang = targetWindow.getAttribute("lang");
    const language = lang || "unknown";
    const allLineEls = targetWindow.querySelectorAll(".caption-visual-line, .ytp-caption-visual-line, .captions-text");
    const leafLineEls = [];
    for (const el of Array.from(allLineEls)) {
      let isParent = false;
      for (const other of Array.from(allLineEls)) {
        if (el !== other && el.contains(other)) {
          isParent = true;
          break;
        }
      }
      if (!isParent) {
        leafLineEls.push(el);
      }
    }
    const lines = [];
    const seenTexts = /* @__PURE__ */ new Set();
    for (const lineEl of leafLineEls) {
      const segments = lineEl.querySelectorAll(".ytp-caption-segment");
      const lineText = Array.from(segments).map((seg) => seg.textContent || "").join("");
      if (lineText && !seenTexts.has(lineText)) {
        lines.push(lineText);
        seenTexts.add(lineText);
      }
    }
    if (lines.length === 0) return null;
    const text = lines.join("\n");
    if (isUiOnlyText(text)) return null;
    return { text, language };
  }
  var youtubePlatform = {
    name: "youtube",
    matchesUrl(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return host === "youtube.com" || host === "www.youtube.com" || host === "m.youtube.com" || host === "youtu.be";
      } catch {
        return false;
      }
    },
    showNativeCaptions,
    hideNativeCaptions,
    startMonitoring(video, onSubtitlesChanged) {
      let finalizedEntries = [];
      let currentEntry = null;
      let lastText2 = "";
      let containerObserver = null;
      let documentObserver = null;
      let lastObservedContainer = null;
      let lastEmittedContentHash = null;
      let lastEmitTime = 0;
      let readDebounceTimer = null;
      const READ_DEBOUNCE_MS = 120;
      let cachedLanguage = "unknown";
      console.log("[mLearn:youtube] startMonitoring called");
      function emitSubtitles(force = false) {
        let entries = [...finalizedEntries];
        if (currentEntry) {
          entries.push({
            ...currentEntry,
            end: Math.max(currentEntry.end, video.currentTime)
          });
        }
        const deduped = [];
        for (const entry of entries) {
          const last = deduped[deduped.length - 1];
          if (last && last.text === entry.text) {
            last.end = Math.max(last.end, entry.end);
          } else {
            deduped.push({ ...entry });
          }
        }
        entries = deduped;
        if (entries.length === 0) return;
        const srtText = generateSRT(entries);
        const contentHash = entries.map((e) => e.text).join("\n");
        const now = Date.now();
        if (!force) {
          if (contentHash === lastEmittedContentHash) return;
          if (now - lastEmitTime < EMIT_THROTTLE_MS) return;
        }
        lastEmittedContentHash = contentHash;
        lastEmitTime = now;
        console.log("[mLearn:youtube] emitSubtitles: entries=", entries.length, "language=", cachedLanguage, "srtLength=", srtText.length);
        onSubtitlesChanged({
          tracks: [],
          textTracks: [{ language: cachedLanguage, text: srtText }]
        });
      }
      function readCaptions() {
        if (readDebounceTimer) {
          clearTimeout(readDebounceTimer);
        }
        readDebounceTimer = setTimeout(() => {
          readDebounceTimer = null;
          doReadCaptions();
        }, READ_DEBOUNCE_MS);
      }
      function doReadCaptions() {
        const container = document.querySelector(CAPTION_CONTAINER_SELECTOR);
        const captionData = container ? extractCaptionText(container) : null;
        const now = video.currentTime;
        console.log("[mLearn:youtube] doReadCaptions: container=", !!container, "captionData=", !!captionData, "currentTime=", now);
        if (captionData?.language) {
          cachedLanguage = captionData.language;
        }
        if (!captionData || captionData.text === "") {
          if (currentEntry) {
            currentEntry.end = now;
            finalizedEntries.push(currentEntry);
            if (finalizedEntries.length > MAX_FINALIZED_ENTRIES) {
              finalizedEntries = finalizedEntries.slice(-MAX_FINALIZED_ENTRIES);
            }
            currentEntry = null;
            lastText2 = "";
            emitSubtitles(true);
          }
          return;
        }
        const text = captionData.text;
        if (text === lastText2) {
          return;
        }
        if (currentEntry && (text.trim().includes(currentEntry.text.trim()) || currentEntry.text.trim().includes(text.trim()))) {
          currentEntry.text = text;
          lastText2 = text;
          emitSubtitles(true);
          return;
        }
        if (currentEntry) {
          currentEntry.end = now;
          finalizedEntries.push(currentEntry);
          if (finalizedEntries.length > MAX_FINALIZED_ENTRIES) {
            finalizedEntries = finalizedEntries.slice(-MAX_FINALIZED_ENTRIES);
          }
        }
        currentEntry = { start: now, end: ACTIVE_CAPTION_END_TIME, text };
        lastText2 = text;
        emitSubtitles(true);
      }
      function observeContainer(container) {
        if (containerObserver) {
          containerObserver.disconnect();
        }
        lastObservedContainer = container;
        containerObserver = new MutationObserver(() => {
          readCaptions();
        });
        containerObserver.observe(container, { childList: true, subtree: true, characterData: true });
        console.log("[mLearn:youtube] Observing caption container");
      }
      function findAndObserveContainer() {
        const container = document.querySelector(CAPTION_CONTAINER_SELECTOR);
        if (container && container !== lastObservedContainer) {
          observeContainer(container);
          readCaptions();
        }
      }
      function setupDocumentObserver() {
        if (documentObserver) return;
        documentObserver = new MutationObserver((mutations) => {
          let shouldCheck = false;
          for (const mutation of mutations) {
            for (const node of Array.from(mutation.addedNodes)) {
              if (node instanceof Element) {
                if (node.matches(CAPTION_CONTAINER_SELECTOR) || node.querySelector(CAPTION_CONTAINER_SELECTOR)) {
                  shouldCheck = true;
                  break;
                }
              }
            }
            if (!shouldCheck && lastObservedContainer && !document.contains(lastObservedContainer)) {
              console.log("[mLearn:youtube] Caption container removed from DOM");
              if (containerObserver) {
                containerObserver.disconnect();
                containerObserver = null;
              }
              lastObservedContainer = null;
              shouldCheck = true;
            }
          }
          if (shouldCheck) {
            findAndObserveContainer();
          }
        });
        documentObserver.observe(document.documentElement, { childList: true, subtree: true });
        console.log("[mLearn:youtube] Document observer set up");
      }
      findAndObserveContainer();
      setupDocumentObserver();
      return () => {
        console.log("[mLearn:youtube] Cleanup called");
        showNativeCaptions();
        if (readDebounceTimer) {
          clearTimeout(readDebounceTimer);
          readDebounceTimer = null;
        }
        if (containerObserver) {
          containerObserver.disconnect();
          containerObserver = null;
        }
        if (documentObserver) {
          documentObserver.disconnect();
          documentObserver = null;
        }
        lastObservedContainer = null;
      };
    }
  };

  // extension/src/platforms/index.ts
  var platforms = [
    youtubePlatform,
    genericPlatform
  ];
  function getSitePlatform(url) {
    for (const platform of platforms) {
      if (platform.matchesUrl(url)) {
        return platform;
      }
    }
    return genericPlatform;
  }

  // extension/src/content-script.ts
  var TIMEUPDATE_THROTTLE_MS = 250;
  var trackedVideo = null;
  var mutationObserver = null;
  var videoAttrObserver = null;
  var isDestroyed = false;
  var geometryInterval = null;
  var lastGeometry = null;
  var lastVolume = -1;
  var headlessModeEnabled = false;
  var headlessSubtitles = [];
  var urlObserver = null;
  var platformCleanup = null;
  var currentPlatform = null;
  function getChromeRuntime() {
    if (typeof chrome !== "undefined" && chrome?.runtime?.sendMessage) {
      return chrome.runtime;
    }
    return void 0;
  }
  function captureVideoScreenshot() {
    if (!trackedVideo?.element || trackedVideo.element.readyState < 2) {
      return "";
    }
    const video = trackedVideo.element;
    const canvas = document.createElement("canvas");
    const maxWidth = 480;
    let width = video.videoWidth;
    let height = video.videoHeight;
    if (width > maxWidth) {
      height = Math.round(height * maxWidth / width);
      width = maxWidth;
    }
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return "";
    }
    ctx.drawImage(video, 0, 0, width, height);
    try {
      return canvas.toDataURL("image/jpeg", 0.7);
    } catch {
      return "";
    }
  }
  function sendVideoScreenshot() {
    const dataUrl = captureVideoScreenshot();
    if (!dataUrl) {
      return;
    }
    const runtime = getChromeRuntime();
    if (!runtime) {
      return;
    }
    const message = {
      type: "VIDEO_SCREENSHOT",
      dataUrl,
      timestamp: Date.now()
    };
    try {
      runtime.sendMessage(message);
    } catch {
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
  }
  function getVideoArea(el) {
    if (!isVisible(el)) return 0;
    const rect = el.getBoundingClientRect();
    return rect.width * rect.height;
  }
  function getAllVideos2(root = document) {
    const found = [];
    try {
      const videos = root.querySelectorAll("video");
      for (const video of Array.from(videos)) {
        found.push(video);
      }
    } catch {
    }
    const allElements = root.querySelectorAll("*");
    for (const el of Array.from(allElements)) {
      if (el.shadowRoot) {
        found.push(...getAllVideos2(el.shadowRoot));
      }
    }
    return found;
  }
  function extractVideoState(video) {
    return {
      currentTime: video.currentTime,
      duration: video.duration,
      isPlaying: !video.paused && !video.ended,
      playbackRate: video.playbackRate,
      volume: video.volume,
      muted: video.muted,
      src: video.currentSrc || video.src || window.location.href,
      isWaiting: trackedVideo?.isWaiting ?? false,
      isFullscreen: !!document.fullscreenElement && document.fullscreenElement.contains(video)
    };
  }
  function sendVideoState(video) {
    const runtime = getChromeRuntime();
    if (!runtime) return;
    const state = extractVideoState(video);
    const message = {
      type: "VIDEO_STATE",
      state,
      meta: {
        url: window.location.href,
        title: document.title
      },
      timestamp: Date.now()
    };
    try {
      runtime.sendMessage(message);
    } catch {
    }
    if (headlessModeEnabled) {
      updateSubtitleForTime(video.currentTime);
    }
  }
  function handleTimeUpdate() {
    if (isDestroyed || !trackedVideo) return;
    const now = Date.now();
    if (now - trackedVideo.lastSentTime < TIMEUPDATE_THROTTLE_MS) return;
    trackedVideo.lastSentTime = now;
    sendVideoState(this);
  }
  function handlePlay() {
    if (isDestroyed || !trackedVideo) return;
    trackedVideo.isWaiting = false;
    sendVideoState(this);
  }
  function handlePause() {
    if (isDestroyed || !trackedVideo) return;
    trackedVideo.isWaiting = false;
    sendVideoState(this);
    sendVideoScreenshot();
  }
  function handleSeeked() {
    if (isDestroyed) return;
    sendVideoState(this);
    sendVideoScreenshot();
  }
  function handleRateChange() {
    if (isDestroyed) return;
    sendVideoState(this);
  }
  function handleVolumeChange() {
    if (isDestroyed || !trackedVideo) return;
    const vol = this.volume;
    if (vol !== lastVolume) {
      lastVolume = vol;
      sendVideoState(this);
    }
  }
  function handleWaiting() {
    if (isDestroyed || !trackedVideo) return;
    trackedVideo.isWaiting = true;
    sendVideoState(this);
  }
  function handleCanPlay() {
    if (isDestroyed || !trackedVideo) return;
    if (trackedVideo.isWaiting) {
      trackedVideo.isWaiting = false;
      sendVideoState(this);
    }
  }
  function handleStalled() {
    if (isDestroyed || !trackedVideo) return;
    trackedVideo.isWaiting = true;
    sendVideoState(this);
  }
  function handleEnded() {
    if (isDestroyed || !trackedVideo) return;
    trackedVideo.isWaiting = false;
    sendVideoState(this);
  }
  function handleLoadedMetadata() {
    if (isDestroyed) return;
    if (trackedVideo) {
      trackedVideo.lastSrc = this.currentSrc || this.src || window.location.href;
    }
    sendVideoState(this);
    startPlatformExtraction(this);
  }
  function handleEmptied() {
    if (isDestroyed || !trackedVideo) return;
    if (this.currentSrc !== trackedVideo.lastSrc) {
      trackedVideo.lastSrc = this.currentSrc || this.src || window.location.href;
      sendVideoState(this);
      startPlatformExtraction(this);
    }
  }
  function handleResize2() {
    if (isDestroyed || !trackedVideo) return;
    sendGeometryUpdate(getVideoGeometry(trackedVideo.element));
  }
  function attachToVideo(video) {
    if (trackedVideo?.element === video) return;
    detachFromVideo();
    trackedVideo = {
      element: video,
      lastSentTime: 0,
      lastSrc: video.currentSrc || video.src || window.location.href,
      isWaiting: false
    };
    lastVolume = video.volume;
    video.addEventListener("timeupdate", handleTimeUpdate);
    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);
    video.addEventListener("seeked", handleSeeked);
    video.addEventListener("ratechange", handleRateChange);
    video.addEventListener("volumechange", handleVolumeChange);
    video.addEventListener("waiting", handleWaiting);
    video.addEventListener("canplay", handleCanPlay);
    video.addEventListener("stalled", handleStalled);
    video.addEventListener("ended", handleEnded);
    video.addEventListener("loadedmetadata", handleLoadedMetadata);
    video.addEventListener("emptied", handleEmptied);
    window.addEventListener("resize", handleResize2);
    videoAttrObserver = new MutationObserver(() => {
      if (isDestroyed || !trackedVideo) return;
      const newSrc = trackedVideo.element.currentSrc || trackedVideo.element.src;
      if (newSrc !== trackedVideo.lastSrc) {
        trackedVideo.lastSrc = newSrc;
        sendVideoState(trackedVideo.element);
        startPlatformExtraction(trackedVideo.element);
      }
    });
    videoAttrObserver.observe(video, { attributes: true, attributeFilter: ["src"] });
    sendVideoState(video);
    startGeometryPolling();
    startPlatformExtraction(video);
    if (headlessModeEnabled) {
      enableSubtitleInjection();
    }
  }
  function getIframeOffset() {
    if (window.self === window.top) return { x: 0, y: 0 };
    try {
      const frameEl = window.frameElement;
      if (frameEl) {
        const frameRect = frameEl.getBoundingClientRect();
        return { x: frameRect.x, y: frameRect.y };
      }
    } catch {
    }
    return { x: 0, y: 0 };
  }
  function getVideoGeometry(video) {
    const rect = video.getBoundingClientRect();
    const iframeOffset = getIframeOffset();
    return {
      rectX: rect.x + iframeOffset.x,
      rectY: rect.y + iframeOffset.y,
      width: rect.width,
      height: rect.height,
      screenX: window.screenX,
      screenY: window.screenY,
      isFullscreen: !!document.fullscreenElement && document.fullscreenElement.contains(video)
    };
  }
  function sendGeometryUpdate(geometry) {
    const runtime = getChromeRuntime();
    if (!runtime) return;
    if (document.hidden) return;
    const message = {
      type: "GEOMETRY_UPDATE",
      geometry,
      timestamp: Date.now()
    };
    try {
      runtime.sendMessage(message);
    } catch {
    }
  }
  function startGeometryPolling() {
    if (geometryInterval) return;
    setTimeout(() => {
      if (isDestroyed || !trackedVideo) return;
      const geometry = getVideoGeometry(trackedVideo.element);
      lastGeometry = geometry;
      sendGeometryUpdate(geometry);
    }, 100);
    let heartbeatCounter = 0;
    geometryInterval = setInterval(() => {
      if (isDestroyed || !trackedVideo) return;
      const geometry = getVideoGeometry(trackedVideo.element);
      heartbeatCounter++;
      const changed = !lastGeometry || lastGeometry.rectX !== geometry.rectX || lastGeometry.rectY !== geometry.rectY || lastGeometry.width !== geometry.width || lastGeometry.height !== geometry.height || lastGeometry.screenX !== geometry.screenX || lastGeometry.screenY !== geometry.screenY || lastGeometry.isFullscreen !== geometry.isFullscreen;
      if (changed || heartbeatCounter >= 10) {
        lastGeometry = geometry;
        sendGeometryUpdate(geometry);
        if (heartbeatCounter >= 10) heartbeatCounter = 0;
      }
    }, 100);
  }
  function stopGeometryPolling() {
    if (geometryInterval) {
      clearInterval(geometryInterval);
      geometryInterval = null;
    }
    lastGeometry = null;
  }
  function detachFromVideo() {
    if (!trackedVideo) return;
    const video = trackedVideo.element;
    video.removeEventListener("timeupdate", handleTimeUpdate);
    video.removeEventListener("play", handlePlay);
    video.removeEventListener("pause", handlePause);
    video.removeEventListener("seeked", handleSeeked);
    video.removeEventListener("ratechange", handleRateChange);
    video.removeEventListener("volumechange", handleVolumeChange);
    video.removeEventListener("waiting", handleWaiting);
    video.removeEventListener("canplay", handleCanPlay);
    video.removeEventListener("stalled", handleStalled);
    video.removeEventListener("ended", handleEnded);
    video.removeEventListener("loadedmetadata", handleLoadedMetadata);
    video.removeEventListener("emptied", handleEmptied);
    window.removeEventListener("resize", handleResize2);
    if (videoAttrObserver) {
      videoAttrObserver.disconnect();
      videoAttrObserver = null;
    }
    if (platformCleanup) {
      platformCleanup();
      platformCleanup = null;
    }
    trackedVideo = null;
    lastVolume = -1;
    stopGeometryPolling();
  }
  function findVideoInNode(node) {
    if (node instanceof HTMLVideoElement) {
      return node;
    }
    if (node instanceof Element) {
      if (node.shadowRoot) {
        const shadowVideo = getBestVideoFromRoot(node.shadowRoot);
        if (shadowVideo) return shadowVideo;
      }
      const video = node.querySelector("video");
      if (video) return video;
    }
    return null;
  }
  function getBestVideoFromRoot(root) {
    const videos = getAllVideos2(root);
    if (videos.length === 0) return null;
    let best = null;
    let bestArea = 0;
    for (const video of videos) {
      const area = getVideoArea(video);
      if (area > bestArea) {
        bestArea = area;
        best = video;
      }
    }
    return best;
  }
  function scanForVideo() {
    return getBestVideoFromRoot(document);
  }
  function shouldSwitchToNewVideo(newVideo) {
    if (!trackedVideo) return true;
    const currentArea = getVideoArea(trackedVideo.element);
    const newArea = getVideoArea(newVideo);
    return newArea > currentArea * 1.25 || currentArea === 0;
  }
  function handleMutations(mutations) {
    if (isDestroyed) return;
    let videoRemoved = false;
    for (const mutation of mutations) {
      for (const removedNode of Array.from(mutation.removedNodes)) {
        if (trackedVideo && (removedNode === trackedVideo.element || removedNode instanceof Element && removedNode.contains(trackedVideo.element))) {
          videoRemoved = true;
          break;
        }
      }
      if (videoRemoved) break;
    }
    if (videoRemoved) {
      detachFromVideo();
    }
    if (!trackedVideo) {
      const video = scanForVideo();
      if (video) {
        attachToVideo(video);
      }
      return;
    }
    for (const mutation of mutations) {
      for (const addedNode of Array.from(mutation.addedNodes)) {
        const video = findVideoInNode(addedNode);
        if (video && video !== trackedVideo.element) {
          if (shouldSwitchToNewVideo(video)) {
            attachToVideo(video);
            return;
          }
        }
      }
    }
  }
  function setupMutationObserver() {
    if (mutationObserver) return;
    mutationObserver = new MutationObserver(handleMutations);
    mutationObserver.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  function teardownMutationObserver() {
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }
  }
  function handlePlatformSubtitles(result, video) {
    console.log("[mLearn:content] handlePlatformSubtitles: tracks=", result.tracks.length, "textTracks=", result.textTracks.length);
    const runtime = getChromeRuntime();
    if (!runtime) return;
    if (result.tracks.length > 0 || result.textTracks.length > 0) {
      try {
        runtime.sendMessage({
          type: "SUBTITLE_TRACKS",
          tracks: result.tracks,
          textTracks: result.textTracks,
          url: window.location.href,
          timestamp: Date.now()
        });
        console.log("[mLearn:content] Sent SUBTITLE_TRACKS");
      } catch {
      }
    }
    if (headlessModeEnabled && result.textTracks.length > 0) {
      const firstTrack = result.textTracks[0];
      try {
        headlessSubtitles = parseSubtitles(firstTrack.text);
        loadSubtitles(headlessSubtitles);
        updateSubtitleForTime(video.currentTime);
      } catch (e) {
        console.error("[mLearn:content] Failed to parse headless subtitles:", e);
      }
    }
  }
  function startPlatformExtraction(video) {
    console.log("[mLearn:content] startPlatformExtraction");
    if (platformCleanup) {
      platformCleanup();
      platformCleanup = null;
    }
    const platform = getSitePlatform(window.location.href);
    currentPlatform = platform;
    console.log("[mLearn:content] Using platform:", platform.name);
    platformCleanup = platform.startMonitoring(video, (result) => {
      handlePlatformSubtitles(result, video);
    });
    if (platform.extractOnce) {
      const result = platform.extractOnce(video);
      if (result) {
        handlePlatformSubtitles(result, video);
      }
    }
  }
  function handleCommandMessage(message, _sender, sendResponse) {
    if (!trackedVideo || isDestroyed) return;
    const cmd = message;
    if (cmd.type !== "EXTENSION_COMMAND") return;
    const video = trackedVideo.element;
    switch (cmd.command) {
      case "play":
        video.play().catch(() => {
        });
        break;
      case "pause":
        video.pause();
        break;
      case "seek":
        if (typeof cmd.time === "number" && isFinite(cmd.time)) {
          video.currentTime = Math.max(0, Math.min(cmd.time, video.duration || Infinity));
        }
        break;
      case "setRate":
        if (typeof cmd.rate === "number" && isFinite(cmd.rate)) {
          video.playbackRate = cmd.rate;
        }
        break;
      case "setVolume":
        if (typeof cmd.volume === "number" && isFinite(cmd.volume)) {
          video.volume = Math.max(0, Math.min(1, cmd.volume));
        }
        break;
      case "showNativeCaptions":
        currentPlatform?.showNativeCaptions?.();
        break;
      case "hideNativeCaptions":
        currentPlatform?.hideNativeCaptions?.();
        break;
      case "captureScreenshot":
        sendVideoScreenshot();
        if (sendResponse) {
          sendResponse({ success: true });
        }
        return true;
    }
  }
  function setupCommandListener() {
    const runtime = getChromeRuntime();
    if (!runtime?.onMessage) return;
    runtime.onMessage.addListener(handleCommandMessage);
  }
  function removeCommandListener() {
    const runtime = getChromeRuntime();
    if (!runtime?.onMessage) return;
    runtime.onMessage.removeListener(handleCommandMessage);
  }
  function handleHeadlessStateChanged(enabled) {
    headlessModeEnabled = enabled;
    if (enabled) {
      enableSubtitleInjection();
      if (trackedVideo) {
        updateSubtitleForTime(trackedVideo.element.currentTime);
      }
    } else {
      disableSubtitleInjection();
      headlessSubtitles = [];
    }
  }
  function handleHeadlessSubtitleLoad(content, format) {
    try {
      headlessSubtitles = parseSubtitles(content, format);
      loadSubtitles(headlessSubtitles);
      if (trackedVideo) {
        updateSubtitleForTime(trackedVideo.element.currentTime);
      }
    } catch {
    }
  }
  function handleHeadlessSubtitleOffset(offset) {
    setSubtitleOffset(offset);
    if (trackedVideo) {
      updateSubtitleForTime(trackedVideo.element.currentTime);
    }
  }
  function handleHeadlessCommand(cmd) {
    if (!trackedVideo || isDestroyed) return;
    const video = trackedVideo.element;
    switch (cmd.command) {
      case "play":
        video.play().catch(() => {
        });
        break;
      case "pause":
        video.pause();
        break;
      case "seek":
        if (typeof cmd.time === "number" && isFinite(cmd.time)) {
          video.currentTime = Math.max(0, Math.min(cmd.time, video.duration || Infinity));
        }
        break;
      case "setRate":
        if (typeof cmd.rate === "number" && isFinite(cmd.rate)) {
          video.playbackRate = cmd.rate;
        }
        break;
      case "setVolume":
        if (typeof cmd.volume === "number" && isFinite(cmd.volume)) {
          video.volume = Math.max(0, Math.min(1, cmd.volume));
        }
        break;
    }
  }
  function handleHeadlessMessage(message) {
    const msg = message;
    switch (msg.type) {
      case "HEADLESS_STATE_CHANGED": {
        const stateMsg = msg;
        handleHeadlessStateChanged(stateMsg.enabled);
        break;
      }
      case "HEADLESS_SUBTITLE_LOAD": {
        const loadMsg = msg;
        handleHeadlessSubtitleLoad(loadMsg.content, loadMsg.format);
        break;
      }
      case "HEADLESS_SUBTITLE_OFFSET": {
        const offsetMsg = msg;
        handleHeadlessSubtitleOffset(offsetMsg.offset);
        break;
      }
      case "HEADLESS_SUBTITLE_UPDATE": {
        const updateMsg = msg;
        updateSubtitleText(updateMsg.text);
        if (trackedVideo) {
          positionSubtitleOverVideo(trackedVideo.element);
        }
        break;
      }
      case "HEADLESS_COMMAND": {
        const cmdMsg = msg;
        handleHeadlessCommand(cmdMsg);
        break;
      }
      case "HEADLESS_SUBTITLE_FONT_SIZE": {
        const fontSizeMsg = msg;
        adjustFontSize(fontSizeMsg.delta);
        break;
      }
    }
  }
  function setupHeadlessMessageListener() {
    const runtime = getChromeRuntime();
    if (!runtime?.onMessage) return;
    runtime.onMessage.addListener(handleHeadlessMessage);
  }
  function removeHeadlessMessageListener() {
    const runtime = getChromeRuntime();
    if (!runtime?.onMessage) return;
    runtime.onMessage.removeListener(handleHeadlessMessage);
  }
  var longPressTimer = null;
  var longPressStartX = 0;
  var longPressStartY = 0;
  var LONG_PRESS_MS = 500;
  var LONG_PRESS_MOVE_THRESHOLD = 10;
  function getWordAtPoint(x, y) {
    const el = document.elementFromPoint(x, y);
    if (!el) return null;
    const text = el.textContent?.trim();
    if (!text) return null;
    const range = document.caretRangeFromPoint(x, y);
    if (!range) return null;
    const textNode = range.startContainer;
    if (!textNode || textNode.nodeType !== Node.TEXT_NODE) {
      const fullText2 = el.textContent || "";
      const words = fullText2.split(/[\s\n]+/);
      for (const w of words) {
        if (w.length > 0) return {
          word: w.replace(/[^\w\p{L}]/gu, ""),
          contextText: fullText2,
          offset: 0
        };
      }
      return null;
    }
    const fullText = textNode.textContent || "";
    const offset = range.startOffset;
    let start = offset;
    let end = offset;
    while (start > 0 && /\w|\p{L}/u.test(fullText[start - 1])) start--;
    while (end < fullText.length && /\w|\p{L}/u.test(fullText[end])) end++;
    if (start === end) return null;
    return {
      word: fullText.slice(start, end),
      contextText: fullText,
      offset: range.startOffset
    };
  }
  function sendCloseHover() {
    const runtime = getChromeRuntime();
    if (runtime) {
      try {
        runtime.sendMessage({ type: "TEXT_MODE_CLOSE_HOVER" });
      } catch {
      }
    }
  }
  function handleKeyDown(e) {
    if (e.key === "Escape") {
      sendCloseHover();
    }
  }
  function handleLongPressStart(e) {
    if (e.button !== 0 || e.ctrlKey || e.metaKey) return;
    sendCloseHover();
    longPressStartX = e.clientX;
    longPressStartY = e.clientY;
    longPressTimer = setTimeout(() => {
      longPressTimer = null;
      const result = getWordAtPoint(e.clientX, e.clientY);
      const word = result?.word ?? "";
      const iframeOffset = getIframeOffset();
      console.log("[mLearn Content] Long-press detected, word:", word, "at client(", longPressStartX, longPressStartY, ") screen(", window.screenX, window.screenY, ")");
      if (word.length > 0) {
        const runtime = getChromeRuntime();
        if (runtime) {
          try {
            runtime.sendMessage({
              type: "TEXT_MODE_WORD_LOOKUP",
              word,
              x: longPressStartX + iframeOffset.x,
              y: longPressStartY + iframeOffset.y,
              screenX: window.screenX,
              screenY: window.screenY,
              contextText: result?.contextText,
              offset: result?.offset
            });
            console.log("[mLearn Content] Sent TEXT_MODE_WORD_LOOKUP for:", word);
          } catch (err) {
            console.log("[mLearn Content] Failed to send word lookup:", err);
          }
        }
      }
    }, LONG_PRESS_MS);
  }
  function handleLongPressMove(e) {
    if (longPressTimer !== null) {
      const dx = e.screenX - longPressStartX;
      const dy = e.screenY - longPressStartY;
      if (Math.abs(dx) > LONG_PRESS_MOVE_THRESHOLD || Math.abs(dy) > LONG_PRESS_MOVE_THRESHOLD) {
        clearTimeout(longPressTimer);
        longPressTimer = null;
      }
    }
  }
  function handleLongPressEnd() {
    if (longPressTimer !== null) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
  }
  function setupTextModeWordLookup() {
    console.log("[mLearn Content] Setting up long-press word lookup");
    document.addEventListener("mousedown", handleLongPressStart);
    document.addEventListener("mousemove", handleLongPressMove);
    document.addEventListener("mouseup", handleLongPressEnd);
    document.addEventListener("mouseleave", handleLongPressEnd);
    document.addEventListener("keydown", handleKeyDown);
  }
  function showTextModeToast(text) {
    const toast = document.createElement("div");
    toast.textContent = text;
    toast.style.cssText = 'position:fixed;bottom:28px;left:50%;transform:translateX(-50%) translateY(12px);background:rgba(15,15,17,0.92);color:#f4f4f5;padding:10px 20px;border-radius:9999px;font-size:13px;font-weight:500;z-index:2147483647;font-family:"Helvetica Neue",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;pointer-events:none;opacity:0;box-shadow:0 4px 16px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.06);transition:opacity 0.35s cubic-bezier(0.4,0,0.2,1),transform 0.35s cubic-bezier(0.4,0,0.2,1);letter-spacing:0.01em;';
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateX(-50%) translateY(0)";
    });
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateX(-50%) translateY(6px)";
      setTimeout(() => toast.remove(), 350);
    }, 2500);
  }
  function handleTextModeLookupMessage(message) {
    const msg = message;
    if (msg.type === "TEXT_MODE_LOOKUP_ERROR" && msg.error === "cannot-connect") {
      showTextModeToast("mLearn: Could not connect to desktop app");
    }
  }
  function setupTextModeMessageListener() {
    const runtime = getChromeRuntime();
    if (!runtime?.onMessage) return;
    runtime.onMessage.addListener(handleTextModeLookupMessage);
  }
  function removeTextModeMessageListener() {
    const runtime = getChromeRuntime();
    if (!runtime?.onMessage) return;
    runtime.onMessage.removeListener(handleTextModeLookupMessage);
  }
  function destroy() {
    isDestroyed = true;
    detachFromVideo();
    teardownMutationObserver();
    stopGeometryPolling();
    removeCommandListener();
    removeHeadlessMessageListener();
    removeTextModeMessageListener();
    if (longPressTimer !== null) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
    document.removeEventListener("mousedown", handleLongPressStart);
    document.removeEventListener("mousemove", handleLongPressMove);
    document.removeEventListener("mouseup", handleLongPressEnd);
    document.removeEventListener("mouseleave", handleLongPressEnd);
    document.removeEventListener("keydown", handleKeyDown);
    disableSubtitleInjection();
    headlessSubtitles = [];
    headlessModeEnabled = false;
    if (urlObserver) {
      urlObserver.disconnect();
      urlObserver = null;
    }
  }
  function initContentScript() {
    if (isDestroyed) return;
    const video = scanForVideo();
    if (video) {
      attachToVideo(video);
    }
    if (window.self !== window.top && !video) {
      return;
    }
    setupMutationObserver();
    setupCommandListener();
    setupHeadlessMessageListener();
    setupTextModeMessageListener();
    setupTextModeWordLookup();
    let lastUrl = window.location.href;
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    function wrappedPushState(...args) {
      const result = originalPushState.apply(this, args);
      checkUrlChange();
      return result;
    }
    function wrappedReplaceState(...args) {
      const result = originalReplaceState.apply(this, args);
      checkUrlChange();
      return result;
    }
    Object.defineProperty(wrappedPushState, "name", { value: "pushState" });
    Object.defineProperty(wrappedPushState, "length", { value: originalPushState.length });
    Object.defineProperty(wrappedReplaceState, "name", { value: "replaceState" });
    Object.defineProperty(wrappedReplaceState, "length", { value: originalReplaceState.length });
    history.pushState = wrappedPushState;
    history.replaceState = wrappedReplaceState;
    window.addEventListener("popstate", checkUrlChange);
    function checkUrlChange() {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        sendCloseHover();
        if (trackedVideo && document.contains(trackedVideo.element)) {
          startPlatformExtraction(trackedVideo.element);
        } else {
          detachFromVideo();
          const newVideo = scanForVideo();
          if (newVideo) {
            attachToVideo(newVideo);
          }
        }
      }
    }
    urlObserver = new MutationObserver(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        checkUrlChange();
      }
    });
    urlObserver.observe(document, { subtree: true, childList: true });
    window.addEventListener("beforeunload", () => {
      destroy();
      urlObserver?.disconnect();
      history.pushState = originalPushState;
      history.replaceState = originalReplaceState;
    });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden && trackedVideo) {
        sendGeometryUpdate(getVideoGeometry(trackedVideo.element));
      }
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initContentScript);
  } else {
    initContentScript();
  }
})();
